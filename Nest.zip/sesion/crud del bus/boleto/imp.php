<?php require_once ("../conexion.php"); ?>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Imp. boleto</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<button  type="button" class="btn btn-warning"onclick="window.print();"><span>Imprimir</span></button>
<div class="main-content">

  
<?php  
$a=$_GET['a'];// destino
$b=$_GET['b'];// boleto 
 " \$a : $a";
 " \$b : $b";
?>


  <div class="ticket">
    <div class="ticket__main">
      <div class="header">BOLETT Express ®</div>
      <div class="info passenger">
        <div class="info__item">Pasajero</div>
        <div class="info__detail"><?php   
        $nombre =mysqli_query($con,"SELECT * FROM `boleto` WHERE id_boleto =".$b."");
        while ($valores = mysqli_fetch_array($nombre)) {echo $valores['nombre']," ",$valores['apellido'] ;}?></div>
      </div>
      <div class="info platform"> <span>BUEN </span> <span>VIAJE</span> <br> <span>TEREHO</span>  <span>PORAITEKE</span>
        
      </div>
      <div class="info departure">
        <div class="info__item">Bus</div>
        <div class="info__detail"><?php   $chapa =mysqli_query($con,"SELECT `chapa` FROM `bus` WHERE id_bus IN(SELECT id_bus FROM destino WHERE (".$a." = destino.id_destino))");
                     while ($valores = mysqli_fetch_array($chapa)) {echo $valores['chapa'] ;}
                      ?></div>
      </div>
      <div class="info arrival">
        <div class="info__item">Destino</div>
        <div class="info__detail"><?php   $destino =mysqli_query($con,"SELECT  `destino` FROM `destino` WHERE id_destino =".$a."");
                     while ($valores = mysqli_fetch_array($destino)) {echo $valores['destino'] ;} ?></div>
      </div>
      <div class="info date">
        <div class="info__item">Día de salida</div>
        <div class="info__detail"><?php $salida_dia =mysqli_query($con,"SELECT `salida_dia` FROM `destino` WHERE id_destino =".$a."");
                     while ($valores = mysqli_fetch_array($salida_dia)) {echo $valores['salida_dia'] ;} ?></div>
      </div>
      <div class="info time">
        <div class="info__item">Hora de salida</div>
        <div class="info__detail"><?php  $salida_hora =mysqli_query($con,"SELECT `salida_hora` FROM `destino` WHERE id_destino =".$a."");
                     while ($valores = mysqli_fetch_array($salida_hora)) {echo $valores['salida_hora'] ;} ?></div>
      </div>
      <div class="info carriage">
        <div class="info__item">Precio(Gs)</div>
        <div class="info__detail"><?php   $query2 =mysqli_query($con,"SELECT  `precio`FROM `destino` WHERE id_destino =".$a."");
                     while ($valores = mysqli_fetch_array($query2)) {echo $valores['precio'];}
                      ?></div>
      </div>
      <div class="info seat">
        <div class="info__item">Asiento</div>
        <div class="info__detail"><?php $asiento =mysqli_query($con,"SELECT * FROM `boleto` WHERE id_boleto =".$b."");
        while ($valores = mysqli_fetch_array($asiento)) {echo $valores['asiento'];} ?></div>
      </div>
      <div class="fineprint"> 
        <p>El embarque inicia 30 minutos antes de la hora de salida. </p>
        <p>Este ticket no es reembolsable • BOLETT Express</p>
      </div>
      <div class="snack">
        <svg viewBox="0 -11 414.00053 414">
          <path d="m202.480469 352.128906c0-21.796875-17.671875-39.46875-39.46875-39.46875-21.800781 0-39.472657 17.667969-39.472657 39.46875 0 21.800782 17.671876 39.472656 39.472657 39.472656 21.785156-.023437 39.445312-17.683593 39.46875-39.472656zm0 0"></path>
          <path d="m348.445312 348.242188c2.148438 21.691406-13.695312 41.019531-35.390624 43.167968-21.691407 2.148438-41.015626-13.699218-43.164063-35.390625-2.148437-21.691406 13.695313-41.019531 35.386719-43.167969 21.691406-2.148437 41.019531 13.699219 43.167968 35.390626zm0 0"></path>
          <path d="m412.699219 63.554688c-1.3125-1.84375-3.433594-2.941407-5.699219-2.941407h-311.386719l-3.914062-24.742187c-3.191407-20.703125-21.050781-35.9531252-42-35.871094h-42.699219c-3.867188 0-7 3.132812-7 7s3.132812 7 7 7h42.699219c14.050781-.054688 26.03125 10.175781 28.171875 24.0625l33.800781 213.515625c3.191406 20.703125 21.050781 35.957031 42 35.871094h208.929687c3.863282 0 7-3.132813 7-7 0-3.863281-3.136718-7-7-7h-208.929687c-14.050781.054687-26.03125-10.175781-28.171875-24.0625l-5.746094-36.300781h213.980469c18.117187-.007813 34.242187-11.484376 40.179687-28.597657l39.699219-114.578125c.742188-2.140625.402344-4.511718-.914062-6.355468zm0 0"></path>
        </svg>
      </div>
      <div class="barcode">
        <div class="barcode__scan"></div>
        <div class="barcode__id"><?php 
        $bolet =mysqli_query($con,"SELECT  `id_boleto` FROM `boleto` WHERE id_boleto =".$b."");
        while ($valores = mysqli_fetch_array($bolet)) {echo "0000000" ,$valores['id_boleto'] ;} ?></div>
      </div>
    </div>
    <div class="ticket__side">
      <div class="logo"> 
        <p>BOLETT Express</p>
      </div>
      <div class="info side-arrive">
        <div class="info__item">C.I.</div>
        <div class="info__detail"><?php 
        $ci =mysqli_query($con,"SELECT  `doc_pas` FROM `boleto` WHERE id_boleto =".$b."");
        while ($valores = mysqli_fetch_array($ci)) {echo $valores['doc_pas'] ;} ?></div>
      </div>
      <div class="info side-depart">
        <div class="info__item">Destino</div>
        <div class="info__detail"><?php   $destino =mysqli_query($con,"SELECT  `destino` FROM `destino` WHERE id_destino =".$a."");
                     while ($valores = mysqli_fetch_array($destino)) {echo $valores['destino'] ;} ?></div>
      </div>
      <div class="info side-date">
        <div class="info__item">Salid. día</div>
        <div class="info__detail"><?php $salida_dia =mysqli_query($con,"SELECT `salida_dia` FROM `destino` WHERE id_destino =".$a."");
                     while ($valores = mysqli_fetch_array($salida_dia)) {echo $valores['salida_dia'] ;} ?></div>
      </div>
      <div class="info side-time">
        <div class="info__item">Salid. Hora</div>
        <div class="info__detail"><?php  $salida_hora =mysqli_query($con,"SELECT `salida_hora` FROM `destino` WHERE id_destino =".$a."");
                     while ($valores = mysqli_fetch_array($salida_hora)) {echo $valores['salida_hora'] ;} ?></div>
      </div>
      <div class="barcode">
        <div class="barcode__scan"></div>
        <div class="barcode__id"><?php 
        $bolet =mysqli_query($con,"SELECT  `id_boleto` FROM `boleto` WHERE id_boleto =".$b."");
        while ($valores = mysqli_fetch_array($bolet)) {echo "0000" ,$valores['id_boleto'] ;} ?></div>
      </div>
    </div>
  </div>
</div>
<aside class="context">
  <div class="explanation"></div>
</aside>