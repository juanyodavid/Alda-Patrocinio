<?php require_once ("cnx.php" ); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Administracion Tareas</title>
    
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../icon/style.css">

	
    <style>
        
        body{
            background-image: url(../image/p3.jpg);
        }
        
        .welcome{
            width: 100%;
            max-width:1100px;
            margin: auto;
            margin-top: 45px;
            background: rgba(0,0,0,0.6);
            text-align: center;
            padding: 20px;
        }
    

        .welcome h1{
            font-size: 50px;
            color: white;
            font-weight: 100;
            margin-top: 20px;
        }
        
        .welcome a{
            display: inline-flex;
            margin-top: 40px;
            font-size: 20px;
            padding: 10px;
            border: 1px solid white;
        }
        
        .welcome a:botton{
            color: black;
            background: white;
        }
		.welcome label{
    font-size: 20px;
			left: -3px;
    position: relative;
    top: 0px;
    color: #0076ff;
}
        
    
    </style>
    
</head>
<body>
	
	
   <div class="welcome">
        <h1>Bienvenido</h1>
   	    <a href="act_datos/tarea.php"><label class="lnr lnr-pencil"></label>Tareas</a>
	    <a href="act_datos/cliente_externo.php"><label class="lnr lnr-pencil"></label>Benef. externos</a>
	    <a href="act_datos/cliente_interno.php"><label class="lnr lnr-pencil"></label>Benef. interno</a>
	    <a href="reporte/reporte.php"><label class="lnr lnr-pencil"></label>Reportes</a>
	    <a href="act_datos/usuario.php"><label class="lnr lnr-pencil"></label>Usuarios</a>
        <a href="cerrar.php"><label class="lnr lnr-exit"></label>Cerrar sesión</a>
        
       
   </div>

</body>
</html>





