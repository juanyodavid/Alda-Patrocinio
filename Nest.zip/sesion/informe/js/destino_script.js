$(function() {
			load(1);// este es el destinocador de la variable
		});
		function load(page){// significa que se ejecuta al ser llamado este archivo ya que se ejecuta la funcion
			var query=$("#q").val(); // la variable "query" es el destinocador y se llama #q (destinocar en lote.php)
			var per_page=10; // declara esta variable con un valor de 10
			var parametros = {"action":"ajax","page":page,'query':query,'per_page':per_page};
			$("#loader").fadeIn('slow');
			$.ajax({
				url:'ajax/destino_ajax/vista_usuario.php ',
// <?php if (isset($_GET['var'])) {echo'ajax/lote_ajax/vista_usuario.php?var=4';} ?>
				data: parametros,
				 beforeSend: function(objeto){
				$("#loader").html("Cargando...");
			  },
				success:function(data){
					$(".outer_div").html(data).fadeIn('slow');
					$("#loader").html("");
				}
			})
		}
		