<?php  require_once ("conexion.php"); ?>
<div id="addProductModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form name="add_product" id="add_product">
					<div class="modal-header">						
						<h4 class="modal-title">Agregar</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						<div class="form-group">
							<label>Client ID</label>
							<input type="number" name="id_add"  id="id_add" class="form-control" required >
							
						</div>
						<div class="form-group">
							<label>Nombre y apellidos</label>
							<input type="text" name="nombre_add"  id="nombre_add" class="form-control" required >
							
						</div>
						<div class="form-group">
							<label>Nº de documento</label>
							<input type="number" name="nd_add"  id="nd_add" class="form-control" required >
							
						</div>
						<div class="form-group">
							<label>Sexo</label><br>
                            <label class="radio-inline"><input type="radio" name="sexo_add" id="sexo_add" value="Hombre" checked  >Hombre</label>
                            <label class="radio-inline" ><input type="radio" name="sexo_add" id="sexo_add" value="Mujer"  >Mujer</label>
                    	</div>
						<div class="form-group">
							<label>Tipo de documento</label>
							<input type="text" name="tipo_doc_add"  id="tipo_doc_add" class="form-control"  >
							
						</div>   
						<div class="form-group">
							<label>Fecha de nacimineto</label>
							<input type="date" name="fecha_add" id="fecha_add" class="form-control" required >
						</div>	
						<div class="form-group">
							<label>Grado</label>
							<input type="text" name="grado_add"  id="grado_add" class="form-control"  >
							
						</div>		
						<div class="form-group">
							<label>Escuela</label>
							<input type="text" name="escuela_add"  id="escuela_add" class="form-control"  >
							
						</div>			
						<div class="form-group">
							<label>Barrio</label>
							<input type="text" name="barrio_add"  id="barrio_add" class="form-control"  >
							
						</div>	
						<div class="form-group">
							<label>Zona</label>
							<select name="zona_add" id="zona_add" class="form-control">
								<option value="Z1- Esc.Juan de Salazar">Z1- Esc.Juan de Salazar</option>
  								<option value="Z2- 16 de Julio">Z2- 16 de Julio</option>
  								<option value="Z3- Sueños del Pilar-Capilla">Z3- Sueños del Pilar-Capilla</option>
  								<option value="Z4- El Bosque Centro Cuminitario">Z4- El Bosque Centro Cuminitario</option>
  								<option value="Z5- Esc. Divino Niño-NE">Z5- Esc. Divino Niño-NE</option>
  								<option value="Z6 - ICM Aguapey">Z6 - ICM Aguapey</option>
  								<option value="Z7- USF Don Bosco">Z7- USF Don Bosco</option>
  								<option value="Z8- Esc. San Vicente de Paul">Z8- Esc. San Vicente de Paul</option>
  								<option value="Z9- Esc. Nuevo Amanecer">Z9- Esc. Nuevo Amanecer</option>
  								<option value="Z10- Salado">Z10- Salado</option>
  								<option value="Z11-Pabla Ferreira">Z11-Pabla Ferreira</option>
  								<option value="Z12- Esc. San Roque-Red">Z12- Esc. San Roque-Red</option>
 								
							</select>
	
						</div>	
						<div class="form-group">
							<label>1º Nombre, Parentezco</label>
							<input type="text" name="np1_add"  id="np1_add" class="form-control"  >
							
						</div>	
						<div class="form-group">
							<label>1º Contacto</label>
							<input type="number" name="c1_add"  id="c1_add" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>2º Nombre, Parentezco</label>
							<input type="text" name="np2_add"  id="np2_add" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>2º Contacto</label>
							<input type="number" name="c2_add"  id="c2_add" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>3º Nombre, Parentezco</label>
							<input type="text" name="np3_add"  id="np3_add" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>3º Contacto</label>
							<input type="number" name="c3_add"  id="c3_add" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>4º Nombre, Parentezco</label>
							<input type="text" name="np4_add"  id="np4_add" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>4º Contacto</label>
							<input type="number" name="c4_add"  id="c4_add" class="form-control"  >
							
						</div>
						  
                        <div class="form-group">
							<label>Referencia doméstica</label>
							<input type="text" name="ref_dom_add"  id="ref_dom_add" class="form-control">
							
						</div>
						<div class="form-group">
							<label>Obs.</label>
							<input type="text" name="observacion_add"  id="observacion_add" class="form-control"  >
							
						</div>
                        <div class="form-group">
							<label>Año de inscripción</label>
							<input type="number" name="ins_add"  id="ins_add" class="form-control"  required>
							
						</div>
                        <div class="form-group">
							<label>Nº de programa</label>
							<input type="number" name="prog_add"  id="prog_add" class="form-control" required >
							
						</div>
                        
                       			
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-success" value="Guardar">
					</div>
				</form>
			</div>
		</div>
	</div>