<?php  require_once ("conexion.php"); ?>

<div id="editProductModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form name="edit_product" id="edit_product">
					<div class="modal-header">						
						<h4 class="modal-title">Editar</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					
					<div class="modal-body">					
						<div class="form-group">
							<label>Client ID</label>
							<input type="number" name="edit_id"  id="edit_id" class="form-control" required>
							<input type="hidden" name="edit_id2"  id="edit_id2" >
							
						</div>
						<div class="form-group">
							<label>Nombre y apellidos</label>
							<input type="text" name="nombre_edit"  id="nombre_edit" class="form-control" required >
							
						</div>
						<div class="form-group">
							<label>Nº de documento</label>
							<input type="number" name="nd_edit"  id="nd_edit" class="form-control" required >
							
						</div>
						<div class="form-group">
							<label>Sexo</label><br>
                            <label class="radio-inline"><input type="radio" name="sexo_edit" id="sexo_edit" value="Hombre" checked  >Hombre</label>
                            <label class="radio-inline" ><input type="radio" name="sexo_edit" id="sexo_edit" value="Mujer"  >Mujer</label>
                    	</div>
						<div class="form-group">
							<label>Tipo de documento</label>
							<input type="text" name="tipo_doc_edit"  id="tipo_doc_edit" class="form-control"  >
							
						</div>   
						<div class="form-group">
							<label>Fecha de nacimineto</label>
							<input type="date" name="fecha_edit" id="fecha_edit" class="form-control" required >
						</div>	
						<div class="form-group">
							<label>Grado</label>
							<input type="text" name="grado_edit"  id="grado_edit" class="form-control"  >
							
						</div>		
						<div class="form-group">
							<label>Escuela</label>
							<input type="text" name="escuela_edit"  id="escuela_edit" class="form-control"  >
							
						</div>			
						<div class="form-group">
							<label>Barrio</label>
							<input type="text" name="barrio_edit"  id="barrio_edit" class="form-control"  >
							
						</div>	
						<div class="form-group">
							<label>Zona</label>
							<select name="zona_edit" id="zona_edit" class="form-control">
								<option value="Z1- Esc.Juan de Salazar">Z1- Esc.Juan de Salazar</option>
  								<option value="Z2- 16 de Julio">Z2- 16 de Julio</option>
  								<option value="Z3- Sueños del Pilar-Capilla">Z3- Sueños del Pilar-Capilla</option>
  								<option value="Z4- El Bosque Centro Cuminitario">Z4- El Bosque Centro Cuminitario</option>
  								<option value="Z5- Esc. Divino Niño-NE">Z5- Esc. Divino Niño-NE</option>
  								<option value="Z6 - ICM Aguapey">Z6 - ICM Aguapey</option>
  								<option value="Z7- USF Don Bosco">Z7- USF Don Bosco</option>
  								<option value="Z8- Esc. San Vicente de Paul">Z8- Esc. San Vicente de Paul</option>
  								<option value="Z9- Esc. Nuevo Amanecer">Z9- Esc. Nuevo Amanecer</option>
  								<option value="Z10- Salado">Z10- Salado</option>
  								<option value="Z11-Pabla Ferreira">Z11-Pabla Ferreira</option>
  								<option value="Z12- Esc. San Roque-Red">Z12- Esc. San Roque-Red</option>
 								
							</select>
						</div>	
						<div class="form-group">
							<label>1º Nombre, Parentezco</label>
							<input type="text" name="np1_edit"  id="np1_edit" class="form-control"  >
							
						</div>	
						<div class="form-group">
							<label>1º Contacto</label>
							<input type="number" name="c1_edit"  id="c1_edit" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>2º Nombre, Parentezco</label>
							<input type="text" name="np2_edit"  id="np2_edit" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>2º Contacto</label>
							<input type="number" name="c2_edit"  id="c2_edit" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>3º Nombre, Parentezco</label>
							<input type="text" name="np3_edit"  id="np3_edit" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>3º Contacto</label>
							<input type="number" name="c3_edit"  id="c3_edit" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>4º Nombre, Parentezco</label>
							<input type="text" name="np4_edit"  id="np4_edit" class="form-control"  >
							
						</div>
						<div class="form-group">
							<label>4º Contacto</label>
							<input type="number" name="c4_edit"  id="c4_edit" class="form-control"  >
							
						</div>
						  
                        <div class="form-group">
							<label>Referencia doméstica</label>
							<input type="text" name="ref_dom_edit"  id="ref_dom_edit" class="form-control">
							
						</div>
						<div class="form-group">
							<label>Obs.</label>
							<input type="text" name="observacion_edit"  id="observacion_edit" class="form-control"  >
							
						</div>
                        <div class="form-group">
							<label>Año de inscripción</label>
							<input type="number" name="ins_edit"  id="ins_edit" class="form-control"  required>
							
						</div>
                        <div class="form-group">
							<label>Nº de programa</label>
							<input type="number" name="prog_edit"  id="prog_edit" class="form-control" required >
							
						</div>
                        
                       			
					</div>

					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-info" value="Guardar">
					</div>
				</form>
			</div>
		</div>
	</div>


