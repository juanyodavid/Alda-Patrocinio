<div id="checkProductModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form name="check_product" id="check_product">
					<div class="modal-header">						
						<h4 class="modal-title">Compra de boleto</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">		
						<p>¿Seguro que quiere confirmar la reserva de este boleto?</p>
						<input type="hidden" name="check_id" id="check_id">
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
						<input type="submit" class="btn btn-primary" value="Confirmar">
					</div>
				</form>
			</div>
		</div>
	</div>