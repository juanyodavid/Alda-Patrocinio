<?php
	if (empty($_POST['edit_id'])){
		$errors[] = "ID está vacío.";
	} elseif (!empty($_POST['edit_id'])){
	require_once ("../../conexion.php");//Contiene funcion que conecta a la base de datos
	// escaping, additionally removing everything that could be (html/javascript-) code
 
    $nombre = mysqli_real_escape_string($con,(strip_tags($_POST["nombre_edit"],ENT_QUOTES)));
	$nd = mysqli_real_escape_string($con,(strip_tags($_POST["nd_edit"],ENT_QUOTES)));
	$sexo = mysqli_real_escape_string($con,(strip_tags($_POST["sexo_edit"],ENT_QUOTES)));
	$tipo_doc = mysqli_real_escape_string($con,(strip_tags($_POST["tipo_doc_edit"],ENT_QUOTES)));
	$fecha = mysqli_real_escape_string($con,(strip_tags($_POST["fecha_edit"],ENT_QUOTES)));
	$grado = mysqli_real_escape_string($con,(strip_tags($_POST["grado_edit"],ENT_QUOTES)));
	$escuela = mysqli_real_escape_string($con,(strip_tags($_POST["escuela_edit"],ENT_QUOTES)));
	$barrio = mysqli_real_escape_string($con,(strip_tags($_POST["barrio_edit"],ENT_QUOTES)));
	$np1 = mysqli_real_escape_string($con,(strip_tags($_POST["np1_edit"],ENT_QUOTES)));
	$c1 = mysqli_real_escape_string($con,(strip_tags($_POST["c1_edit"],ENT_QUOTES)));
	$np2 = mysqli_real_escape_string($con,(strip_tags($_POST["np2_edit"],ENT_QUOTES)));
	$c2 = mysqli_real_escape_string($con,(strip_tags($_POST["c2_edit"],ENT_QUOTES)));
	$np3 = mysqli_real_escape_string($con,(strip_tags($_POST["np3_edit"],ENT_QUOTES)));
	$c3 = mysqli_real_escape_string($con,(strip_tags($_POST["c3_edit"],ENT_QUOTES)));
	$np4 = mysqli_real_escape_string($con,(strip_tags($_POST["np3_edit"],ENT_QUOTES)));
	$c4 = mysqli_real_escape_string($con,(strip_tags($_POST["c3_edit"],ENT_QUOTES)));
	$ref = mysqli_real_escape_string($con,(strip_tags($_POST["ref_dom_edit"],ENT_QUOTES)));
	$observacion = mysqli_real_escape_string($con,(strip_tags($_POST["observacion_edit"],ENT_QUOTES)));
	$ins = mysqli_real_escape_string($con,(strip_tags($_POST["ins_edit"],ENT_QUOTES)));
	$zona = mysqli_real_escape_string($con,(strip_tags($_POST["zona_edit"],ENT_QUOTES)));
	$prog = mysqli_real_escape_string($con,(strip_tags($_POST["prog_edit"],ENT_QUOTES)));
	$id=mysqli_real_escape_string($con,(strip_tags($_POST["edit_id"],ENT_QUOTES)));
	$ide=mysqli_real_escape_string($con,(strip_tags($_POST["edit_id2"],ENT_QUOTES)));
	// UPDATE data into database
    $sql = "UPDATE beneficiario_interno SET 
	CLIENT_ID='".$id."',nomap='".$nombre."',docn='".$nd."',sexo='".$sexo."',tipodoc='".$tipo_doc."',grado='".$grado."',escuela='".$escuela."',barrio='".$barrio."',
	contacto1='".$c1."',nombre_paren1='".$np1."',contacto2='".$c2."',nombre_paren2='".$np2."',contacto3='".$c3."',nombre_paren3='".$np3."',contacto4='".$c4."',nombre_paren4='".$np4."',
	referdom='".$ref."',obs='".$observacion."',insc='".$ins."',programa='".$prog."',zona='".$zona."' WHERE CLIENT_ID='".$ide."' ";
	$query = mysqli_query($con,$sql);
    // if product has been added successfully
    if ($query) {
        $messages[] = "Actualización exitosa.";
    } else {
        $errors[] = "Actualización fallida.";
    }
		
	} else 
	{
		$errors[] = "desconocido.";
	}
if (isset($errors)){
			
			?>
			<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>Error!</strong> 
					<?php
						foreach ($errors as $error) {
								echo $error;
							}
						?>
			</div>
			<?php
			}
			if (isset($messages)){
				
				?>
				<div class="alert alert-success" role="alert">
						<button type="button" class="close" data-dismiss="alert">&times;</button>
						<strong>Concretada.</strong>
						<?php
							foreach ($messages as $message) {
									echo $message;
								}
							?>
				</div>
				<?php
			}
?>