<?php
	
	/* Connect To Database*/
	require_once ("../../conexion.php");

	
$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
if($action == 'ajax'){
	$query = mysqli_real_escape_string($con,(strip_tags($_REQUEST['query'], ENT_QUOTES)));

	$tables="beneficiario_interno";
	$campos="*";
	$sWhere="beneficiario_interno.nomap LIKE '%".$query."%'";
	$sWhere.=" order by beneficiario_interno.nomap";
	
	
	
	include '../pagination.php'; //include pagination file
	//pagination variables
	$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
	$per_page = intval($_REQUEST['per_page']); //how much records you want to show
	$adjacents  = 4; //gap between pages after number of adjacents
	$offset = ($page - 1) * $per_page;
	//Count the total number of row in your table*/
	$count_query   = mysqli_query($con,"SELECT count(*) AS numrows FROM $tables where $sWhere ");
	if ($row= mysqli_fetch_array($count_query)){$numrows = $row['numrows'];}
	else {echo mysqli_error($con);}
	$total_pages = ceil($numrows/$per_page);
	//main query to fetch the data
	$query = mysqli_query($con,"SELECT $campos FROM  $tables where $sWhere LIMIT $offset,$per_page");
	//loop through fetched data
	if ($numrows>0){
		
	?>
		<div class="table-responsive">
			
			<table class="table table-striped table-hover">

				<thead>

					<tr>
						<th class='text-center'>ID cliente</th>  
						<th class='text-center'>Nombre y a.</th>  
						<th class='text-center'>Tipo de doc.</th>
						<th class='text-center'>Nº de doc.</th>  
						<th class='text-center'>Sexo</th>  
						<th class='text-center'>F. de nac.</th>  
						<th class='text-center'>Grado</th>  
						<th class='text-center'>Escuela</th>  
						<th class='text-center'>Barrio</th>  
						<th class='text-center'>Zona</th>  
						<th class='text-center'>1º Nombre, Parentezco</th>  
						<th class='text-center'>1º Contacto</th>  
						<th class='text-center'>2º Nombre, Parentezco</th>  
						<th class='text-center'>2º Contacto</th>  
						<th class='text-center'>3º Nombre, Parentezco</th>  
						<th class='text-center'>3º Contacto</th>  
						<th class='text-center'>4º Nombre, Parentezco</th>  
						<th class='text-center'>4º Contacto</th>  
						<th class='text-center'>Ref. doméstica</th>  
						<th class='text-center'>Obs.</th>  
						<th class='text-center'>Año de inscripción</th>  
						<th class='text-center'>Nº de programa</th>  
						
			
						
						<th></th>
					</tr>
				</thead>
				<tbody>	
						<?php 
						$finales=0;
						while($row = mysqli_fetch_array($query)){	
							$p_1=$row['CLIENT_ID'];
							$p_2=$row['zona'];
							$p_3=$row['nomap'];
							$p_4=$row['tipodoc'];
							$p_5=$row['docn'];
							$p_6=$row['sexo'];
							$p_7=$row['fecnac'];
							$p_8=$row['grado'];
							$p_9=$row['escuela'];
							$p_10=$row['barrio'];
							$p_11=$row['nombre_paren1'];
							$p_12=$row['contacto1'];
							$p_13=$row['nombre_paren2'];
							$p_14=$row['contacto2'];
							$p_15=$row['nombre_paren3'];
							$p_16=$row['contacto3'];
							$p_17=$row['referdom'];
							$p_18=$row['obs'];
							$p_19=$row['insc'];
							$p_20=$row['programa'];
							$p_21=$row['nombre_paren4'];
							$p_22=$row['contacto4'];
							
																				
							$finales++;
						?>	
						<tr >
							<td class='text-center'><?php echo $p_1;?></td>
							<td class='text-center'><?php echo $p_3;?></td>
							<td class='text-center'><?php echo $p_4;?></td>
							<td class='text-center'><?php echo $p_5;?></td>
							<td class='text-center'><?php echo $p_6;?></td>
							<td class='text-center'><?php echo $p_7;?></td>
							<td class='text-center'><?php echo $p_8;?></td>
							<td class='text-center'><?php echo $p_9;?></td>
							<td class='text-center'><?php echo $p_10;?></td>
							<td class='text-center'><?php echo $p_2;?></td>
							<td class='text-center'><?php echo $p_11;?></td>
							<td class='text-center'><?php echo $p_12;?></td>
							<td class='text-center'><?php echo $p_13;?></td>
							<td class='text-center'><?php echo $p_14;?></td>
							<td class='text-center'><?php echo $p_15;?></td>
							<td class='text-center'><?php echo $p_16;?></td>
							<td class='text-center'><?php echo $p_21;?></td>
							<td class='text-center'><?php echo $p_22;?></td>
							<td class='text-center'><?php echo $p_17;?></td>
							<td class='text-center'><?php echo $p_18;?></td>
							<td class='text-center'><?php echo $p_19;?></td>
							<td class='text-center'><?php echo $p_20;?></td>
	
							
							
							<td><a href="#"data-target="#editProductModal" class="edit" data-toggle="modal" 
							data-id="<?php echo $p_1;?>"
							data-nombre="<?php echo $p_3;?>"
							data-nd ="<?php echo $p_5;?>"
							data-sexo ="<?php echo $p_6;?>"
							data-tipo_doc ="<?php echo $p_4;?>"
							data-fecha ="<?php echo $p_7;?>"
							data-grado="<?php echo $p_8;?>"
							data-escuela="<?php echo $p_9;?>"
							data-barrio ="<?php echo $p_10;?>"
							data-zona ="<?php echo $p_2;?>"
							data-np1 ="<?php echo $p_11;?>"
							data-c1 ="<?php echo $p_12;?>"
							data-np2 ="<?php echo $p_13;?>"
							data-c2 ="<?php echo $p_14;?>"
							data-np3="<?php echo $p_15;?>"
							data-c3 ="<?php echo $p_16;?>"
							data-np4="<?php echo $p_21;?>"
							data-c4 ="<?php echo $p_22;?>"
							data-ref_dom="<?php echo $p_17;?>"
							data-observacion="<?php echo $p_18;?>"
							data-ins="<?php echo $p_19;?>"
							data-prog="<?php echo $p_20;?>"

							 ><i class="material-icons" data-toggle="tooltip" title="Editar" >&#xE254;</i></a>
								<a href="#deleteProductModal" class="delete" data-toggle="modal" data-id="<?php echo $p_1;?>"><i class="material-icons" data-toggle="tooltip" title="Eliminar">&#xE872;</i></a>
                    		</td>
							
							
							
							
							
							
						</tr>
						<?php }?>
						<tr>
							<td colspan='21'> 
								<?php 
									$inicios=$offset+1;
									$finales+=$inicios -1;
									echo "Mostrando $inicios al $finales de $numrows registros";
									echo paginate( $page, $total_pages, $adjacents);
								?>
							</td>
						</tr>
				</tbody>			
			</table>
		</div>	

	
	
	<?php	
	}	
}
?>          



