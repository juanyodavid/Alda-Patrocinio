<?php
	if (empty($_POST['id_add'])){
		$errors[] = "Ingresa el nombre del producto.";
	} 
	elseif (!empty($_POST['id_add'])){
	require_once ("../../conexion.php");//Contiene funcion que conecta a la base de datos
	// escaping, additionally removing everything that could be (html/javascript-) editor_nombre
    $id_cliente = mysqli_real_escape_string($con,(strip_tags($_POST["id_add"],ENT_QUOTES)));
    $nombre = mysqli_real_escape_string($con,(strip_tags($_POST["nombre_add"],ENT_QUOTES)));
	$nd = mysqli_real_escape_string($con,(strip_tags($_POST["nd_add"],ENT_QUOTES)));
	$sexo = mysqli_real_escape_string($con,(strip_tags($_POST["sexo_add"],ENT_QUOTES)));
	$tipo_doc = mysqli_real_escape_string($con,(strip_tags($_POST["tipo_doc_add"],ENT_QUOTES)));
	$fecha = mysqli_real_escape_string($con,(strip_tags($_POST["fecha_add"],ENT_QUOTES)));
	$zona = mysqli_real_escape_string($con,(strip_tags($_POST["zona_add"],ENT_QUOTES)));

	$grado = mysqli_real_escape_string($con,(strip_tags($_POST["grado_add"],ENT_QUOTES)));
	$escuela = mysqli_real_escape_string($con,(strip_tags($_POST["escuela_add"],ENT_QUOTES)));
	$barrio = mysqli_real_escape_string($con,(strip_tags($_POST["barrio_add"],ENT_QUOTES)));
	$np1 = mysqli_real_escape_string($con,(strip_tags($_POST["np1_add"],ENT_QUOTES)));
	$c1 = mysqli_real_escape_string($con,(strip_tags($_POST["c1_add"],ENT_QUOTES)));
	$np2 = mysqli_real_escape_string($con,(strip_tags($_POST["np2_add"],ENT_QUOTES)));
	$c2 = mysqli_real_escape_string($con,(strip_tags($_POST["c2_add"],ENT_QUOTES)));
	$np3 = mysqli_real_escape_string($con,(strip_tags($_POST["np3_add"],ENT_QUOTES)));
	$c4 = mysqli_real_escape_string($con,(strip_tags($_POST["c4_add"],ENT_QUOTES)));
	$np4 = mysqli_real_escape_string($con,(strip_tags($_POST["np4_add"],ENT_QUOTES)));
	
	$c3 = mysqli_real_escape_string($con,(strip_tags($_POST["c3_add"],ENT_QUOTES)));
	$ref = mysqli_real_escape_string($con,(strip_tags($_POST["ref_dom_add"],ENT_QUOTES)));
	$observacion = mysqli_real_escape_string($con,(strip_tags($_POST["observacion_add"],ENT_QUOTES)));
	$ins = mysqli_real_escape_string($con,(strip_tags($_POST["ins_add"],ENT_QUOTES)));
	$prog = mysqli_real_escape_string($con,(strip_tags($_POST["prog_add"],ENT_QUOTES)));

	// REGISTER data into database
    $sql = "INSERT INTO beneficiario_interno(CLIENT_ID,nomap,docn,sexo,tipodoc,grado,escuela,barrio,contacto1,nombre_paren1,contacto2,nombre_paren2,contacto3,nombre_paren3,contacto4,nombre_paren4,referdom,obs,insc,programa,zona,fecnac ) VALUES 
											('$id_cliente','$nombre','$nd','$sexo','$tipo_doc','$grado','$escuela','$barrio','$c1','$np1','$c2','$np2','$c3','$np3','$c4','$np4','$ref','$observacion','$ins','$prog','$zona','$fecha')";    
    $query = mysqli_query($con,$sql);
	// if product has been added successfully
	
    if ($query) {
        $messages[] = "Carga exitosa.";
    } 
		else {
        $errors[] = "Carga fallida. Controle que el ID ingresado no sea repetido.";    }
		
	} else 
	{
		$errors[] = "desconocido.";
	}
if (isset($errors)){
			
			?>
			<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert">&times;</button>
					<strong>Error!</strong> 
					<?php
						foreach ($errors as $error) {
								echo $error;
							}
						?>
			</div>
			<?php
			}
			if (isset($messages)){
				
				?>
				<div class="alert alert-success" role="alert">
						<button type="button" class="close" data-dismiss="alert">&times;</button>
						<strong>Concretada</strong>
						<?php
							foreach ($messages as $message) {
									echo $message;
								}
							?>
				</div>
				<?php
			}
?>