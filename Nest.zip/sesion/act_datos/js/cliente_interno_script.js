$(function() {
			load(1);// este es el buscador de la variable
		});
		function load(page){
			var query=$("#q").val();
			var per_page=10;
			var parametros = {"action":"ajax","page":page,'query':query,'per_page':per_page};
			$("#loader").fadeIn('slow');
			$.ajax({
				url:'ajax/cliente_interno_ajax/vista_usuario.php',
				data: parametros,
				 beforeSend: function(objeto){
				$("#loader").html("Cargando...");
			  },
				success:function(data){
					$(".outer_div").html(data).fadeIn('slow');
					$("#loader").html("");
				}
			})
		}
		$('#editProductModal').on('show.bs.modal', function (event) {
		  var button = $(event.relatedTarget) // Button that triggered the modal
		  var id = button.data('id') 
		  $('#edit_id').val(id)

		 	var id_add2 = button.data('id_add') 
		  $('#edit_id2').val(id_add)

            var nombre = button.data('nombre') // crea la variable lote_edit
		  $('#nombre_edit').val(nombre)
		  var nd = button.data('nd') // crea la variable lote_edit
		  $('#nd_edit').val(nd)
			var  sexo = button.data('sexo') 
		  $('#sexo_edit').val(sexo)
             var tipo_doc = button.data('tipo_doc') 
		  $('#tipo_doc_edit').val(tipo_doc)
		  var fecha = button.data('fecha') 
		  $('#fecha_edit').val(fecha)
		  var grado = button.data('grado') 
		  $('#grado_edit').val(grado)
            var escuela = button.data('escuela') 
		  $('#escuela_edit').val(escuela)
             var barrio = button.data('barrio') 
		  $('#barrio_edit').val(barrio)
             var np1 = button.data('np1') 
		  $('#np1_edit').val(np1)
		  var c1 = button.data('c1') 
		  $('#c1_edit').val(c1)
             var np2 = button.data('np2') 
		  $('#np2_edit').val(np2)
		  var c2 = button.data('c2') 
		  $('#c2_edit').val(c2)
             var np4 = button.data('np4') 
		  $('#np4_edit').val(np4)
		  var c4 = button.data('c4') 
		  $('#c4_edit').val(c4)
		  var np3 = button.data('np3')
		  $('#np3_edit').val(np3)         
		  var c3 = button.data('c3') 
		  $('#c3_edit').val(c3)
		  var ref_dom = button.data('ref_dom')
		  $('#ref_dom_edit').val(ref_dom)
             var observacion = button.data('observacion') 
		  $('#observacion_edit').val(observacion)
             var ins = button.data('ins') 
		  $('#ins_edit').val(ins)
             var zona = button.data('zona') 
		  $('#zona_edit').val(zona)
             var prog = button.data('prog') 
		  $('#prog_edit').val(prog)
 

		})
		
		$('#deleteProductModal').on('show.bs.modal', function (event) {
		  var button = $(event.relatedTarget) // Button that triggered the modal
		  var id = button.data('id') 
		  $('#delete_id').val(id)
		})
		
		
		$( "#edit_product" ).submit(function( event ) {
		  var parametros = $(this).serialize();
			$.ajax({
					type: "POST",
					url: "ajax/cliente_interno_ajax/editar_producto.php",
					data: parametros,
					 beforeSend: function(objeto){
						$("#resultados").html("Enviando...");
					  },
					success: function(datos){
					$("#resultados").html(datos);
					load(1);
					$('#editProductModal').modal('hide');
				  }
			});
		  event.preventDefault();
		});
		
		
		$( "#add_product" ).submit(function( event ) {
		  var parametros = $(this).serialize();
			$.ajax({
					type: "POST",
					url: "ajax/cliente_interno_ajax/guardar_producto.php",
					data: parametros,
					 beforeSend: function(objeto){
						$("#resultados").html("Enviando...");
					  },
					success: function(datos){
					$("#resultados").html(datos);
					load(1);
					$('#addProductModal').modal('hide');
				  }
			});
		  event.preventDefault();
		});
		
		$( "#delete_product" ).submit(function( event ) {
		  var parametros = $(this).serialize();
			$.ajax({
					type: "POST",
					url: "ajax/cliente_interno_ajax/eliminar_producto.php",
					data: parametros,
					 beforeSend: function(objeto){
						$("#resultados").html("Enviando...");
					  },
					success: function(datos){
					$("#resultados").html(datos);
					load(1);
					$('#deleteProductModal').modal('hide');
				  }
			});
		  event.preventDefault();
		});