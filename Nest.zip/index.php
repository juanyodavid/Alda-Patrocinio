<?php 
header('location: sesion/login.php')

 ?>