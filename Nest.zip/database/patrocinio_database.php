<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 4.8.4
 */

/**
 * Database `patrocinio_database`
 */

/* `patrocinio_database`.`anl_cpr` */
$anl_cpr = array(
);

/* `patrocinio_database`.`beneficiario_externo` */
$beneficiario_externo = array(
);

/* `patrocinio_database`.`beneficiario_interno` */
$beneficiario_interno = array(
);

/* `patrocinio_database`.`cdf_pend` */
$cdf_pend = array(
);

/* `patrocinio_database`.`cdg` */
$cdg = array(
);

/* `patrocinio_database`.`facilitador` */
$facilitador = array(
);

/* `patrocinio_database`.`final_l` */
$final_l = array(
);

/* `patrocinio_database`.`inquiry` */
$inquiry = array(
);

/* `patrocinio_database`.`sl_rl` */
$sl_rl = array(
);

/* `patrocinio_database`.`welcome_l` */
$welcome_l = array(
);
