
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `table 5`
--

DROP TABLE IF EXISTS `table 5`;
CREATE TABLE IF NOT EXISTS `table 5` (
  `COL 1` int(10) DEFAULT NULL,
  `COL 2` varchar(42) DEFAULT NULL,
  `COL 3` varchar(10) DEFAULT NULL,
  `COL 4` varchar(6) DEFAULT NULL,
  `COL 5` varchar(10) DEFAULT NULL,
  `COL 6` varchar(13) DEFAULT NULL,
  `COL 7` varchar(48) DEFAULT NULL,
  `COL 8` varchar(44) DEFAULT NULL,
  `COL 9` varchar(32) DEFAULT NULL,
  `COL 10` varchar(34) DEFAULT NULL,
  `COL 11` varchar(37) DEFAULT NULL,
  `COL 12` varchar(30) DEFAULT NULL,
  `COL 13` varchar(43) DEFAULT NULL,
  `COL 14` varchar(21) DEFAULT NULL,
  `COL 15` varchar(32) DEFAULT NULL,
  `COL 16` varchar(16) DEFAULT NULL,
  `COL 17` varchar(91) DEFAULT NULL,
  `COL 18` varchar(208) DEFAULT NULL,
  `COL 19` varchar(169) DEFAULT NULL,
  `COL 20` varchar(198) DEFAULT NULL,
  `COL 21` varchar(166) DEFAULT NULL,
  `COL 22` varchar(5) DEFAULT NULL,
  `COL 23` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
